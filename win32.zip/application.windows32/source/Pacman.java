import processing.core.*; 
import processing.data.*; 
import processing.event.*; 
import processing.opengl.*; 

import java.util.HashMap; 
import java.util.ArrayList; 
import java.io.File; 
import java.io.BufferedReader; 
import java.io.PrintWriter; 
import java.io.InputStream; 
import java.io.OutputStream; 
import java.io.IOException; 

public class Pacman extends PApplet {

/*
This game is heavily inspired by Pacman a game created by Namco, Toru Iwatani, and Shigeo Funaki
I have based the shape of the map, and the basic gameplay off Pacman - 
though I did not copy any code from the original pacman or other clones
I mostly programmed this based off my studies in Intro to Porgramming, though I did have to look online for advice on some technical issues
*/

public void setup()
{
  smooth();
  size (800,1000);
  backgroundSetup();
  pacManSetup();
  powerPelletsSetup();
  pelletsSetup();
  ghostSetup();
  grid();
}

public void draw()
{
  drawBackground(gameStatus);
  if(gameStatus==1)
  {
    drawPacman(pacManX, pacManY, pacManSizeX, pacManSizeY);
    movement();
    eat();
    pacManX=teleport(pacManX, pacManY);
    timeEvents();
    if (powerPelletEaten)
    {
      eatPowerPellet();
      eatGhosts();
    }
    else
    {
      ghostActions();
    }
    win();
    lose();
    levelTime++;
    timeSinceEaten++;
  }
}



//0.03*width = left hand border
//0.97*width = right hand border
//~0.025*height = top border
//~0.79*height = bottom border

//x=0.01*width, y=0.01*height
//Spacing: 3.5x for X coordinates (pellets), 2.6y for y coordinates
//Plus 5.5x for x axis, plus 4y on y axis

//time variables needed:
//time for level - to create score mulitplyer
//time since eaten - to set up ghost actions
//time since power pellet eaten - to set up blue ghost actions (need to set up movements)



float [][] corners;

public void grid()
{
  noStroke();
  
  corners = new float[66][6];
  corners[0][0]=3.5f*x;
  corners[0][1]=2.5f*y;
  corners[0][2]=0;
  corners[0][3]=1;
  corners[0][4]=1;
  corners[0][5]=0;
  
  corners[1][0]=21*x;
  corners[1][1]=2.5f*y;
  corners[1][2]=0;
  corners[1][3]=1;
  corners[1][4]=1;
  corners[1][5]=1;
  
  corners[2][0]=41.5f*x;
  corners[2][1]=2.5f*y;
  corners[2][2]=0;
  corners[2][3]=0;
  corners[2][4]=1;
  corners[2][5]=1;
  
  corners[3][0]=52.5f*x;
  corners[3][1]=2.5f*y;
  corners[3][2]=0;
  corners[3][3]=1;
  corners[3][4]=1;
  corners[3][5]=0;
  
  corners[4][0]=73.5f*x;
  corners[4][1]=2.5f*y;
  corners[4][2]=0;
  corners[4][3]=1;
  corners[4][4]=1;
  corners[4][5]=1;
  
  corners[5][0]=91*x;
  corners[5][1]=2.5f*y;
  corners[5][2]=0;
  corners[5][3]=0;
  corners[5][4]=1;
  corners[5][5]=1;
  
  corners[6][0]=3.5f*x;
  corners[6][1]=12.5f*y;
  corners[6][2]=1;
  corners[6][3]=1;
  corners[6][4]=1;
  corners[6][5]=0;
  
  corners[7][0]=21*x;
  corners[7][1]=12.5f*y;
  corners[7][2]=1;
  corners[7][3]=1;
  corners[7][4]=1;
  corners[7][5]=1;
  
  corners[8][0]=31*x;
  corners[8][1]=12.5f*y;
  corners[8][2]=0;
  corners[8][3]=1;
  corners[8][4]=1;
  corners[8][5]=1;
  
  corners[9][0]=41.5f*x;
  corners[9][1]=12.5f*y;
  corners[9][2]=1;
  corners[9][3]=1;
  corners[9][4]=0;
  corners[9][5]=1;
  
  corners[10][0]=52.5f*x;
  corners[10][1]=12.5f*y;
  corners[10][2]=1;
  corners[10][3]=1;
  corners[10][4]=0;
  corners[10][5]=1;
  
  corners[11][0]=62.5f*x;
  corners[11][1]=12.5f*y;
  corners[11][2]=0;
  corners[11][3]=1;
  corners[11][4]=1;
  corners[11][5]=1;
  
  corners[12][0]=73.5f*x;
  corners[12][1]=12.5f*y;
  corners[12][2]=1;
  corners[12][3]=1;
  corners[12][4]=1;
  corners[12][5]=1;
  
  corners[13][0]=91*x;
  corners[13][1]=12.5f*y;
  corners[13][2]=1;
  corners[13][3]=0;
  corners[13][4]=1;
  corners[13][5]=1;
  
  corners[14][0]=3.5f*x;
  corners[14][1]=20.5f*y;
  corners[14][2]=1;
  corners[14][3]=1;
  corners[14][4]=0;
  corners[14][5]=0;
  
  corners[15][0]=21*x;
  corners[15][1]=20.5f*y;
  corners[15][2]=1;
  corners[15][3]=0;
  corners[15][4]=1;
  corners[15][5]=1;
  
  corners[16][0]=31*x;
  corners[16][1]=20.5f*y;
  corners[16][2]=1;
  corners[16][3]=1;
  corners[16][4]=0;
  corners[16][5]=0;
  
  corners[17][0]=41.5f*x;
  corners[17][1]=20.5f*y;
  corners[17][2]=0;
  corners[17][3]=0;
  corners[17][4]=1;
  corners[17][5]=1;
  
  corners[18][0]=52.5f*x;
  corners[18][1]=20.5f*y;
  corners[18][2]=0;
  corners[18][3]=1;
  corners[18][4]=1;
  corners[18][5]=0;
  
  corners[19][0]=62.5f*x;
  corners[19][1]=20.5f*y;
  corners[19][2]=1;
  corners[19][3]=0;
  corners[19][4]=0;
  corners[19][5]=1;
  
  corners[20][0]=73.5f*x;
  corners[20][1]=20.5f*y;
  corners[20][2]=1;
  corners[20][3]=1;
  corners[20][4]=1;
  corners[20][5]=0;
  
  corners[21][0]=91*x;
  corners[21][1]=20.5f*y;
  corners[21][2]=1;
  corners[21][3]=0;
  corners[21][4]=0;
  corners[21][5]=1;
  
  corners[22][0]=0;
  corners[22][1]=0;
  corners[22][2]=0;
  corners[22][3]=0;
  corners[22][4]=0;
  corners[22][5]=0;
  
  corners[23][0]=31*x;
  corners[23][1]=28.5f*y;
  corners[23][2]=0;
  corners[23][3]=1;
  corners[23][4]=1;
  corners[23][5]=0;
  
  corners[24][0]=41.5f*x;
  corners[24][1]=28.5f*y;
  corners[24][2]=1;
  corners[24][3]=1;
  corners[24][4]=0;
  corners[24][5]=1;
  
  corners[25][0]=52.5f*x;
  corners[25][1]=28.5f*y;
  corners[25][2]=1;
  corners[25][3]=1;
  corners[25][4]=0;
  corners[25][5]=1;
  
  corners[26][0]=62.5f*x;
  corners[26][1]=28.5f*y;
  corners[26][2]=0;
  corners[26][3]=0;
  corners[26][4]=1;
  corners[26][5]=1;
  
  corners[27][0]=0;
  corners[27][1]=0;
  corners[27][2]=0;
  corners[27][3]=0;
  corners[27][4]=0;
  corners[27][5]=0;
  
  corners[28][0]=21*x;
  corners[28][1]=36*y;
  corners[28][2]=1;
  corners[28][3]=1;
  corners[28][4]=1;
  corners[28][5]=1;
  
  corners[29][0]=31*x;
  corners[29][1]=36*y;
  corners[29][2]=1;
  corners[29][3]=0;
  corners[29][4]=1;
  corners[29][5]=1;
  
  corners[30][0]=62.5f*x;
  corners[30][1]=36*y;
  corners[30][2]=1;
  corners[30][3]=1;
  corners[30][4]=1;
  corners[30][5]=0;
  
  corners[31][0]=73.5f*x;
  corners[31][1]=36*y;
  corners[31][2]=1;
  corners[31][3]=1;
  corners[31][4]=1;
  corners[31][5]=1;
  
  corners[32][0]=31*x;
  corners[32][1]=43.5f*y;
  corners[32][2]=1;
  corners[32][3]=1;
  corners[32][4]=1;
  corners[32][5]=0;
  
  corners[33][0]=62.5f*x;
  corners[33][1]=43.5f*y;
  corners[33][2]=1;
  corners[33][3]=0;
  corners[33][4]=1;
  corners[33][5]=1;
  
  corners[34][0]=3.5f*x;
  corners[34][1]=51.5f*y;
  corners[34][2]=0;
  corners[34][3]=1;
  corners[34][4]=1;
  corners[34][5]=0;
  
  corners[35][0]=21*x;
  corners[35][1]=51.5f*y;
  corners[35][2]=1;
  corners[35][3]=1;
  corners[35][4]=1;
  corners[35][5]=1;
  
  corners[36][0]=31*x;
  corners[36][1]=51.5f*y;
  corners[36][2]=1;
  corners[36][3]=1;
  corners[36][4]=0;
  corners[36][5]=1;
  
  corners[37][0]=41.5f*x;
  corners[37][1]=51.5f*y;
  corners[37][2]=0;
  corners[37][3]=0;
  corners[37][4]=1;
  corners[37][5]=1;
  
  corners[38][0]=52.5f*x;
  corners[38][1]=51.5f*y;
  corners[38][2]=0;
  corners[38][3]=1;
  corners[38][4]=1;
  corners[38][5]=0;
  
  corners[39][0]=62.5f*x;
  corners[39][1]=51.5f*y;
  corners[39][2]=1;
  corners[39][3]=1;
  corners[39][4]=0;
  corners[39][5]=1;
  
  corners[40][0]=73.5f*x;
  corners[40][1]=51.5f*y;
  corners[40][2]=1;
  corners[40][3]=1;
  corners[40][4]=1;
  corners[40][5]=1;
  
  corners[41][0]=91*x;
  corners[41][1]=51.5f*y;
  corners[41][2]=0;
  corners[41][3]=0;
  corners[41][4]=1;
  corners[41][5]=1;
  
  corners[42][0]=3.5f*x;
  corners[42][1]=59*y;
  corners[42][2]=1;
  corners[42][3]=1;
  corners[42][4]=0;
  corners[42][5]=0;
  
  corners[43][0]=10*x;
  corners[43][1]=59*y;
  corners[43][2]=0;
  corners[43][3]=0;
  corners[43][4]=1;
  corners[43][5]=1;
  
  corners[44][0]=21*x;
  corners[44][1]=59*y;
  corners[44][2]=1;
  corners[44][3]=1;
  corners[44][4]=1;
  corners[44][5]=0;
  
  corners[45][0]=31*x;
  corners[45][1]=59*y;
  corners[45][2]=0;
  corners[45][3]=1;
  corners[45][4]=1;
  corners[45][5]=1;
  
  corners[46][0]=41.5f*x;
  corners[46][1]=59*y;
  corners[46][2]=1;
  corners[46][3]=1;
  corners[46][4]=0;
  corners[46][5]=1;
  
  corners[47][0]=52.5f*x;
  corners[47][1]=59*y;
  corners[47][2]=1;
  corners[47][3]=1;
  corners[47][4]=0;
  corners[47][5]=1;
  
  corners[48][0]=62.5f*x;
  corners[48][1]=59*y;
  corners[48][2]=0;
  corners[48][3]=1;
  corners[48][4]=1;
  corners[48][5]=1;
  
  corners[49][0]=73.5f*x;
  corners[49][1]=59*y;
  corners[49][2]=1;
  corners[49][3]=0;
  corners[49][4]=1;
  corners[49][5]=1;
  
  corners[50][0]=84*x;
  corners[50][1]=59*y;
  corners[50][2]=0;
  corners[50][3]=1;
  corners[50][4]=1;
  corners[50][5]=0;
  
  corners[51][0]=91*x;
  corners[51][1]=59*y;
  corners[51][2]=1;
  corners[51][3]=0;
  corners[51][4]=0;
  corners[51][5]=1;
  
  corners[52][0]=3.5f*x;
  corners[52][1]=67*y;
  corners[52][2]=0;
  corners[52][3]=1;
  corners[52][4]=1;
  corners[52][5]=0;
  
  corners[53][0]=10*x;
  corners[53][1]=67*y;
  corners[53][2]=1;
  corners[53][3]=1;
  corners[53][4]=0;
  corners[53][5]=1;
  
  corners[54][0]=21*x;
  corners[54][1]=67*y;
  corners[54][2]=1;
  corners[54][3]=0;
  corners[54][4]=0;
  corners[54][5]=1;
  
  corners[55][0]=31*x;
  corners[55][1]=67*y;
  corners[55][2]=1;
  corners[55][3]=1;
  corners[55][4]=0;
  corners[55][5]=0;
  
  corners[56][0]=41.5f*x;
  corners[56][1]=67*y;
  corners[56][2]=0;
  corners[56][3]=0;
  corners[56][4]=1;
  corners[56][5]=1;
  
  corners[57][0]=52.5f*x;
  corners[57][1]=67*y;
  corners[57][2]=0;
  corners[57][3]=1;
  corners[57][4]=1;
  corners[57][5]=0;
  
  corners[58][0]=62.5f*x;
  corners[58][1]=67*y;
  corners[58][2]=1;
  corners[58][3]=0;
  corners[58][4]=0;
  corners[58][5]=1;
  
  corners[59][0]=73.5f*x;
  corners[59][1]=67*y;
  corners[59][2]=1;
  corners[59][3]=1;
  corners[59][4]=0;
  corners[59][5]=0;
  
  corners[60][0]=84*x;
  corners[60][1]=67*y;
  corners[60][2]=1;
  corners[60][3]=1;
  corners[60][4]=0;
  corners[60][5]=1;
  
  corners[61][0]=91*x;
  corners[61][1]=67*y;
  corners[61][2]=0;
  corners[61][3]=0;
  corners[61][4]=1;
  corners[61][5]=1;
  
  corners[62][0]=3.5f*x;
  corners[62][1]=74.5f*y;
  corners[62][2]=1;
  corners[62][3]=1;
  corners[62][4]=0;
  corners[62][5]=0;
  
  corners[63][0]=41.5f*x;
  corners[63][1]=74.5f*y;
  corners[63][2]=1;
  corners[63][3]=1;
  corners[63][4]=0;
  corners[63][5]=1;
  
  corners[64][0]=52.5f*x;
  corners[64][1]=74.5f*y;
  corners[64][2]=1;
  corners[64][3]=1;
  corners[64][4]=0;
  corners[64][5]=1;
  
  corners[65][0]=91*x;
  corners[65][1]=74.5f*y;
  corners[65][2]=1;
  corners[65][3]=0;
  corners[65][4]=0;
  corners[65][5]=1;
  
}
PImage [] map;
PImage[] arrows;
PImage student, blinky, pinky, inky, clyde, ghostBlue;
float arrowUpX, arrowUpY, arrowRightX, arrowRightY, arrowDownX, arrowDownY, arrowLeftX, arrowLeftY, arrowSizeX, arrowSizeY;
int arrayDepth, level, score, lives, levelTime, timeSinceEaten, gameStatus, levelScore;
boolean winLevel, gamePaused;
float x, y;

public void backgroundSetup()
{
  x=width*0.01f;
  y=height*0.01f;
  arrayDepth=3;
  score=0;
  levelScore=0;
  level=1;
  lives=3;
  levelTime=0;
  timeSinceEaten=0;
  gameStatus=0;
  gamePaused=false;
  winLevel=true;
  pellet = loadImage("pellet.jpg");
  powerPellet1= loadImage("powerPellet1.gif");
  powerPellet2= loadImage("powerPellet2.gif");
  student = loadImage("student.gif");
  blinky = loadImage("blinky.gif");
  pinky = loadImage("pinky.gif");
  inky = loadImage("inky.gif");
  clyde = loadImage("clyde.gif");
  ghostBlue = loadImage("scaredGhost.gif");
  powerPellet=powerPellet1;
  map = new PImage[5];
  for (int i=0;i<5;i++)
  {
    map[i]=loadImage("map"+i+".jpg");
  }
  arrows=new PImage[8];
  for (int i=0; i<8; i++)
  {
    arrows[i]= loadImage("arrows"+i+".gif");
  }
  arrowUpX=46*x;
  arrowUpY=83.5f*y;
  arrowRightX=52*x;
  arrowRightY=87.5f*y;
  arrowDownX=46*x;
  arrowDownY=92*y;
  arrowLeftX=40*x;
  arrowLeftY=87.5f*y;
  arrowSizeX=7*x;
  arrowSizeY=6*y;
}

public void drawBackground(int status)
{
  if (status==0)
  {
    image(map[0],0,0,width,height);
  }
  else if (status==1)
  {
    if (level==1)
    {
      image(map[1],0,0,width,height);
    }
    else
    {
      image(map[2],0,0,width,height);
    }
    pellet();
    powerPellet();
    for (int i=0;i<lives;i++)
    {
      drawPacman(width*0.85f+(i*(5*x)),height*0.45f,3*x,2*y);
    }
  }
  else if (status==2)
  {
    image(map[3],0,0,width,height);
    fill(242,211,155);
    textSize(5*y);
    text(score,33*x,42*y);
    noFill();
  }
  else
  {
    image(map[4],0,0,width,height);
    fill(242,211,155);
    textSize(5*y);
    text(score,33*x,42*y);
    noFill();
  }
  drawArrows();
}

public void timeEvents()
{
  if(timeSinceEaten>120){blinkyGo=true;}
  if(timeSinceEaten>240){inkyGo=true;}
  if(timeSinceEaten>360){pinkyGo=true;}
  if(timeSinceEaten>580){clydeGo=true;}
}

public void drawArrows()
{
  if(direction==1)
  {
    image(arrows[1],arrowUpX,arrowUpY,arrowSizeX,arrowSizeY);
    image(arrows[2],arrowRightX,arrowRightY,arrowSizeX,arrowSizeY);
    image(arrows[4],arrowDownX,arrowDownY,arrowSizeX,arrowSizeY);
    image(arrows[6],arrowLeftX,arrowLeftY,arrowSizeX,arrowSizeY);
  }
  else if (direction==2)
  {
    image(arrows[0],arrowUpX,arrowUpY,arrowSizeX,arrowSizeY);
    image(arrows[3],arrowRightX,arrowRightY,arrowSizeX,arrowSizeY);
    image(arrows[4],arrowDownX,arrowDownY,arrowSizeX,arrowSizeY);
    image(arrows[6],arrowLeftX,arrowLeftY,arrowSizeX,arrowSizeY);
  }
  else if (direction==3)
  {
    image(arrows[0],arrowUpX,arrowUpY,arrowSizeX,arrowSizeY);
    image(arrows[2],arrowRightX,arrowRightY,arrowSizeX,arrowSizeY);
    image(arrows[5],arrowDownX,arrowDownY,arrowSizeX,arrowSizeY);
    image(arrows[6],arrowLeftX,arrowLeftY,arrowSizeX,arrowSizeY);
  }
  else if (direction==4)
  {
    image(arrows[0],arrowUpX,arrowUpY,arrowSizeX,arrowSizeY);
    image(arrows[2],arrowRightX,arrowRightY,arrowSizeX,arrowSizeY);
    image(arrows[4],arrowDownX,arrowDownY,arrowSizeX,arrowSizeY);
    image(arrows[7],arrowLeftX,arrowLeftY,arrowSizeX,arrowSizeY);
  }
  else
  {
    image(arrows[0],arrowUpX,arrowUpY,arrowSizeX,arrowSizeY);
    image(arrows[2],arrowRightX,arrowRightY,arrowSizeX,arrowSizeY);
    image(arrows[4],arrowDownX,arrowDownY,arrowSizeX,arrowSizeY);
    image(arrows[6],arrowLeftX,arrowLeftY,arrowSizeX,arrowSizeY);
  }
}


public void blinkyMovement()
{
  if (blinkyGo)
  {
    if(blinkyDirection==1)
    {
      blinkyY-=ghostSpeed;
    }
    else if(blinkyDirection==2)
    {
      blinkyX+=ghostSpeed;
    }
    else if(blinkyDirection==3)
    {
      blinkyY+=ghostSpeed;
    }
    else if(blinkyDirection==4)
    {
      blinkyX-=ghostSpeed;
    }
    
    for (int i=0;i<66;i++)
    {
      if ((blinkyX>corners[i][0]-(ghostSpeed-1))&&(blinkyX<corners[i][0]+(ghostSpeed-1))&&(blinkyY>corners[i][1]-(ghostSpeed-1))&&(blinkyY<corners[i][1]+(ghostSpeed-1)))
      {
        if (blinkyDirection==1)
        {
          if (corners[i][2]==0)
          {
            if ((corners[i][3]==1)&&(corners[i][5]==0)) {blinkyDirection=2;}
            else if ((corners[i][3]==0)&&(corners[i][5]==1)) {blinkyDirection=4;}
            else
            {
              if (pacManX<blinkyX) {blinkyDirection=4;}
              else {blinkyDirection=2;}
            }
          }
          else
          {
            if((corners[i][3]==1)&&(corners[i][5]==0))
            {
              if (pacManY>blinkyY) {blinkyDirection=2;}
            }
            else if ((corners[i][3]==0)&&(corners[i][5]==1))
            {
              if (pacManY>blinkyY) {blinkyDirection=4;}
            }
            else
            {
              if (pacManY>blinkyY)
              {
                if (pacManX<blinkyX) {blinkyDirection=4;}
                else {blinkyDirection=2;}
              }
            }
          }
        }
        else if (blinkyDirection==2)
        {
          if (corners[i][3]==0)
          {
            if ((corners[i][2]==1)&&(corners[i][4]==0)) {blinkyDirection=1;}
            else if ((corners[i][2]==0)&&(corners[i][4]==1)) {blinkyDirection=3;}
            else
            {
              if (pacManY<blinkyY) {blinkyDirection=1;}
              else {blinkyDirection=3;}
            }
          }
          else
          {
            if ((corners[i][2]==1)&&(corners[i][4]==0))
            {
              if (pacManX<blinkyX) {blinkyDirection=1;}
            }
            else if ((corners[i][2]==0)&&(corners[i][4]==1))
            {
              if (pacManX<blinkyX) {blinkyDirection=3;}
            }
            else
            {
              if (pacManX<blinkyX)
              {
                if (pacManY<blinkyY) {blinkyDirection=1;}
                else {blinkyDirection=3;}
              }
            }
          }
        }
        else if (blinkyDirection==3)
        {
          if (corners[i][4]==0)
          {
            if ((corners[i][3]==1)&&(corners[i][5]==0)) {blinkyDirection=2;}
            else if ((corners[i][3]==0)&&(corners[i][5]==1)) {blinkyDirection=4;}
            else
            {
              if (pacManX<blinkyX) {blinkyDirection=4;}
              else {blinkyDirection=2;}
            }
          }
          else
          {
            if ((corners[i][3]==1)&&(corners[i][5]==0))
            {
              if (pacManY<blinkyY) {blinkyDirection=2;}
            }
            else if ((corners[i][3]==0)&&(corners[i][5]==1))
            {
              if (pacManY<blinkyY) {blinkyDirection=4;}
            }
            else
            {
              if (pacManY<blinkyY)
              {
                if (pacManX<blinkyX) {blinkyDirection=4;}
                else {blinkyDirection=2;}
              }
            }
          }
        }
        else
        {
          if (corners[i][5]==0)
          {
            if ((corners[i][2]==1)&&(corners[i][4]==0)) {blinkyDirection=1;}
            else if ((corners[i][2]==0)&&(corners[i][4]==1)) {blinkyDirection=3;}
            else
            {
              if(pacManY<blinkyY) {blinkyDirection=1;}
              else {blinkyDirection=3;}
            }
          }
          else
          {
            if ((corners[i][2]==1)&&(corners[i][4]==0))
            {
              if (pacManX>blinkyX) {blinkyDirection=1;}
            }
            else if ((corners[i][2]==0)&&(corners[i][4]==1))
            {
              if (pacManX>blinkyX) {blinkyDirection=3;}
            }
            else 
            {
              if (pacManX>blinkyX) 
              {
                if (pacManY<blinkyY) {blinkyDirection=1;}
                else {blinkyDirection=3;}
              }
            }
          }
        }
      }
    }
    image (blinky,blinkyX,blinkyY,ghostSizeX,ghostSizeY);
  }
}

public void blueBlinkyMovement()
{
  if (blinkyGo)
  {
    if(blinkyDirection==1)
    {
      blinkyY-=ghostSpeed;
    }
    else if(blinkyDirection==2)
    {
      blinkyX+=ghostSpeed;
    }
    else if(blinkyDirection==3)
    {
      blinkyY+=ghostSpeed;
    }
    else if(blinkyDirection==4)
    {
      blinkyX-=ghostSpeed;
    }
    
    for (int i=0;i<66;i++)
    {
      if ((blinkyX>corners[i][0]-(ghostSpeed-1))&&(blinkyX<corners[i][0]+(ghostSpeed-1))&&(blinkyY>corners[i][1]-(ghostSpeed-1))&&(blinkyY<corners[i][1]+(ghostSpeed-1)))
      {
        if (blinkyDirection==1)
        {
          if (corners[i][2]==0)
          {
            if ((corners[i][3]==1)&&(corners[i][5]==0)) {blinkyDirection=2;}
            else if ((corners[i][3]==0)&&(corners[i][5]==1)) {blinkyDirection=4;}
            else
            {
              if (pacManX>blinkyX) {blinkyDirection=4;}
              else {blinkyDirection=2;}
            }
          }
          else
          {
            if((corners[i][3]==1)&&(corners[i][5]==0))
            {
              if (pacManY<blinkyY) {blinkyDirection=2;}
            }
            else if ((corners[i][3]==0)&&(corners[i][5]==1))
            {
              if (pacManY<blinkyY) {blinkyDirection=4;}
            }
            else
            {
              if (pacManY<blinkyY)
              {
                if (pacManX>blinkyX) {blinkyDirection=4;}
                else {blinkyDirection=2;}
              }
            }
          }
        }
        else if (blinkyDirection==2)
        {
          if (corners[i][3]==0)
          {
            if ((corners[i][2]==1)&&(corners[i][4]==0)) {blinkyDirection=1;}
            else if ((corners[i][2]==0)&&(corners[i][4]==1)) {blinkyDirection=3;}
            else
            {
              if (pacManY>blinkyY) {blinkyDirection=1;}
              else {blinkyDirection=3;}
            }
          }
          else
          {
            if ((corners[i][2]==1)&&(corners[i][4]==0))
            {
              if (pacManX>blinkyX) {blinkyDirection=1;}
            }
            else if ((corners[i][2]==0)&&(corners[i][4]==1))
            {
              if (pacManX>blinkyX) {blinkyDirection=3;}
            }
            else
            {
              if (pacManX>blinkyX)
              {
                if (pacManY>blinkyY) {blinkyDirection=1;}
                else {blinkyDirection=3;}
              }
            }
          }
        }
        else if (blinkyDirection==3)
        {
          if (corners[i][4]==0)
          {
            if ((corners[i][3]==1)&&(corners[i][5]==0)) {blinkyDirection=2;}
            else if ((corners[i][3]==0)&&(corners[i][5]==1)) {blinkyDirection=4;}
            else
            {
              if (pacManX>blinkyX) {blinkyDirection=4;}
              else {blinkyDirection=2;}
            }
          }
          else
          {
            if ((corners[i][3]==1)&&(corners[i][5]==0))
            {
              if (pacManY>blinkyY) {blinkyDirection=2;}
            }
            else if ((corners[i][3]==0)&&(corners[i][5]==1))
            {
              if (pacManY>blinkyY) {blinkyDirection=4;}
            }
            else
            {
              if (pacManY>blinkyY)
              {
                if (pacManX>blinkyX) {blinkyDirection=4;}
                else {blinkyDirection=2;}
              }
            }
          }
        }
        else
        {
          if (corners[i][5]==0)
          {
            if ((corners[i][2]==1)&&(corners[i][4]==0)) {blinkyDirection=1;}
            else if ((corners[i][2]==0)&&(corners[i][4]==1)) {blinkyDirection=3;}
            else
            {
              if(pacManY>blinkyY) {blinkyDirection=1;}
              else {blinkyDirection=3;}
            }
          }
          else
          {
            if ((corners[i][2]==1)&&(corners[i][4]==0))
            {
              if (pacManX<blinkyX) {blinkyDirection=1;}
            }
            else if ((corners[i][2]==0)&&(corners[i][4]==1))
            {
              if (pacManX<blinkyX) {blinkyDirection=3;}
            }
            else 
            {
              if (pacManX<blinkyX) 
              {
                if (pacManY>blinkyY) {blinkyDirection=1;}
                else {blinkyDirection=3;}
              }
            }
          }
        }
      }
    }
    image(ghostBlue,blinkyX,blinkyY,ghostSizeX,ghostSizeY);
  }
}
public void clydeMovement()
{
  if (clydeGo)
  {
    if(clydeDirection==1)
    {
      clydeY-=ghostSpeed;
    }
    else if(clydeDirection==2)
    {
      clydeX+=ghostSpeed;
    }
    else if(clydeDirection==3)
    {
      clydeY+=ghostSpeed;
    }
    else if(clydeDirection==4)
    {
      clydeX-=ghostSpeed;
    }
    
    for (int i=0;i<66;i++)
    {
      if ((clydeX>corners[i][0]-(ghostSpeed-1))&&(clydeX<corners[i][0]+(ghostSpeed-1))&&(clydeY>corners[i][1]-(ghostSpeed-1))&&(clydeY<corners[i][1]+(ghostSpeed-1)))
      {
        if (clydeDirection==1)
        {
          if (corners[i][2]==0)
          {
            if ((corners[i][3]==1)&&(corners[i][5]==0)) {clydeDirection=2;}
            else if ((corners[i][3]==0)&&(corners[i][5]==1)) {clydeDirection=4;}
            else
            {
              if (PApplet.parseInt(random(-5,5))<0) {clydeDirection=4;}
              else {clydeDirection=2;}
            }
          }
          else
          {
            if((corners[i][3]==1)&&(corners[i][5]==0))
            {
              if (PApplet.parseInt(random(-5,5))<0) {clydeDirection=2;}
            }
            else if ((corners[i][3]==0)&&(corners[i][5]==1))
            {
              if (PApplet.parseInt(random(-5,5))<0) {clydeDirection=4;}
            }
            else
            {
              if (PApplet.parseInt(random(-5,5))<0)
              {
                if (PApplet.parseInt(random(-5,5))<0) {clydeDirection=4;}
                else {clydeDirection=2;}
              }
            }
          }
        }
        else if (clydeDirection==2)
        {
          if (corners[i][3]==0)
          {
            if ((corners[i][2]==1)&&(corners[i][4]==0)) {clydeDirection=1;}
            else if ((corners[i][2]==0)&&(corners[i][4]==1)) {clydeDirection=3;}
            else
            {
              if (PApplet.parseInt(random(-5,5))<0) {clydeDirection=1;}
              else {clydeDirection=3;}
            }
          }
          else
          {
            if ((corners[i][2]==1)&&(corners[i][4]==0))
            {
              if (PApplet.parseInt(random(-5,5))<0) {clydeDirection=1;}
            }
            else if ((corners[i][2]==0)&&(corners[i][4]==1))
            {
              if (PApplet.parseInt(random(-5,5))<0) {clydeDirection=3;}
            }
            else
            {
              if (PApplet.parseInt(random(-5,5))<0)
              {
                if (PApplet.parseInt(random(-5,5))<0) {clydeDirection=1;}
                else {clydeDirection=3;}
              }
            }
          }
        }
        else if (clydeDirection==3)
        {
          if (corners[i][4]==0)
          {
            if ((corners[i][3]==1)&&(corners[i][5]==0)) {clydeDirection=2;}
            else if ((corners[i][3]==0)&&(corners[i][5]==1)) {clydeDirection=4;}
            else
            {
              if (PApplet.parseInt(random(-5,5))<0) {clydeDirection=4;}
              else {clydeDirection=2;}
            }
          }
          else
          {
            if ((corners[i][3]==1)&&(corners[i][5]==0))
            {
              if (PApplet.parseInt(random(-5,5))<0) {clydeDirection=2;}
            }
            else if ((corners[i][3]==0)&&(corners[i][5]==1))
            {
              if (PApplet.parseInt(random(-5,5))<0) {clydeDirection=4;}
            }
            else
            {
              if (PApplet.parseInt(random(-5,5))<0)
              {
                if (PApplet.parseInt(random(-5,5))<0) {clydeDirection=4;}
                else {clydeDirection=2;}
              }
            }
          }
        }
        else
        {
          if (corners[i][5]==0)
          {
            if ((corners[i][2]==1)&&(corners[i][4]==0)) {clydeDirection=1;}
            else if ((corners[i][2]==0)&&(corners[i][4]==1)) {clydeDirection=3;}
            else
            {
              if(PApplet.parseInt(random(-5,5))<0) {clydeDirection=1;}
              else {clydeDirection=3;}
            }
          }
          else
          {
            if ((corners[i][2]==1)&&(corners[i][4]==0))
            {
              if (PApplet.parseInt(random(-5,5))<0) {clydeDirection=1;}
            }
            else if ((corners[i][2]==0)&&(corners[i][4]==1))
            {
              if (PApplet.parseInt(random(-5,5))<0) {clydeDirection=3;}
            }
            else 
            {
              if (PApplet.parseInt(random(-5,5))<0) 
              {
                if (PApplet.parseInt(random(-5,5))<0) {clydeDirection=1;}
                else {clydeDirection=3;}
              }
            }
          }
        }
      }
    }
    image(clyde,clydeX,clydeY,ghostSizeX,ghostSizeY);
  }
}

public void blueClydeMovement()
{
  if (clydeGo)
  {
    if(clydeDirection==1)
    {
      clydeY-=ghostSpeed;
    }
    else if(clydeDirection==2)
    {
      clydeX+=ghostSpeed;
    }
    else if(clydeDirection==3)
    {
      clydeY+=ghostSpeed;
    }
    else if(clydeDirection==4)
    {
      clydeX-=ghostSpeed;
    }
    
    for (int i=0;i<66;i++)
    {
      if ((clydeX>corners[i][0]-(ghostSpeed-1))&&(clydeX<corners[i][0]+(ghostSpeed-1))&&(clydeY>corners[i][1]-(ghostSpeed-1))&&(clydeY<corners[i][1]+(ghostSpeed-1)))
      {
        if (clydeDirection==1)
        {
          if (corners[i][2]==0)
          {
            if ((corners[i][3]==1)&&(corners[i][5]==0)) {clydeDirection=2;}
            else if ((corners[i][3]==0)&&(corners[i][5]==1)) {clydeDirection=4;}
            else
            {
              if (PApplet.parseInt(random(-5,5))<0) {clydeDirection=4;}
              else {clydeDirection=2;}
            }
          }
          else
          {
            if((corners[i][3]==1)&&(corners[i][5]==0))
            {
              if (PApplet.parseInt(random(-5,5))<0) {clydeDirection=2;}
            }
            else if ((corners[i][3]==0)&&(corners[i][5]==1))
            {
              if (PApplet.parseInt(random(-5,5))<0) {clydeDirection=4;}
            }
            else
            {
              if (PApplet.parseInt(random(-5,5))<0)
              {
                if (PApplet.parseInt(random(-5,5))<0) {clydeDirection=4;}
                else {clydeDirection=2;}
              }
            }
          }
        }
        else if (clydeDirection==2)
        {
          if (corners[i][3]==0)
          {
            if ((corners[i][2]==1)&&(corners[i][4]==0)) {clydeDirection=1;}
            else if ((corners[i][2]==0)&&(corners[i][4]==1)) {clydeDirection=3;}
            else
            {
              if (PApplet.parseInt(random(-5,5))<0) {clydeDirection=1;}
              else {clydeDirection=3;}
            }
          }
          else
          {
            if ((corners[i][2]==1)&&(corners[i][4]==0))
            {
              if (PApplet.parseInt(random(-5,5))<0) {clydeDirection=1;}
            }
            else if ((corners[i][2]==0)&&(corners[i][4]==1))
            {
              if (PApplet.parseInt(random(-5,5))<0) {clydeDirection=3;}
            }
            else
            {
              if (PApplet.parseInt(random(-5,5))<0)
              {
                if (PApplet.parseInt(random(-5,5))<0) {clydeDirection=1;}
                else {clydeDirection=3;}
              }
            }
          }
        }
        else if (clydeDirection==3)
        {
          if (corners[i][4]==0)
          {
            if ((corners[i][3]==1)&&(corners[i][5]==0)) {clydeDirection=2;}
            else if ((corners[i][3]==0)&&(corners[i][5]==1)) {clydeDirection=4;}
            else
            {
              if (PApplet.parseInt(random(-5,5))<0) {clydeDirection=4;}
              else {clydeDirection=2;}
            }
          }
          else
          {
            if ((corners[i][3]==1)&&(corners[i][5]==0))
            {
              if (PApplet.parseInt(random(-5,5))<0) {clydeDirection=2;}
            }
            else if ((corners[i][3]==0)&&(corners[i][5]==1))
            {
              if (PApplet.parseInt(random(-5,5))<0) {clydeDirection=4;}
            }
            else
            {
              if (PApplet.parseInt(random(-5,5))<0)
              {
                if (PApplet.parseInt(random(-5,5))<0) {clydeDirection=4;}
                else {clydeDirection=2;}
              }
            }
          }
        }
        else
        {
          if (corners[i][5]==0)
          {
            if ((corners[i][2]==1)&&(corners[i][4]==0)) {clydeDirection=1;}
            else if ((corners[i][2]==0)&&(corners[i][4]==1)) {clydeDirection=3;}
            else
            {
              if(PApplet.parseInt(random(-5,5))<0) {clydeDirection=1;}
              else {clydeDirection=3;}
            }
          }
          else
          {
            if ((corners[i][2]==1)&&(corners[i][4]==0))
            {
              if (PApplet.parseInt(random(-5,5))<0) {clydeDirection=1;}
            }
            else if ((corners[i][2]==0)&&(corners[i][4]==1))
            {
              if (PApplet.parseInt(random(-5,5))<0) {clydeDirection=3;}
            }
            else 
            {
              if (PApplet.parseInt(random(-5,5))<0) 
              {
                if (PApplet.parseInt(random(-5,5))<0) {clydeDirection=1;}
                else {clydeDirection=3;}
              }
            }
          }
        }
      }
    }
    image(ghostBlue,clydeX,clydeY,ghostSizeX,ghostSizeY);
  }
}
public void win()
{
  winLevel=true;
  for(int i=0;i<pelletNo;i++)
  {
    if(pellets[i][0]==1)
    {
      winLevel=false;
    }
  }
  for(int i=0; i<powerPelletsNo;i++)
  {
    if(powerPellets[i][0]==2)
    {
      winLevel=false;
    }
  }
  if (winLevel)
  {
    pacManSetup();
    ghostSetup();
    powerPelletsSetup();
    powerPellet=powerPellet2;
    pelletsSetup();
    level++;
    if (levelTime<5400)
    {
      score+=levelScore*2;
    }
    else
    {
      score+=levelScore;
    }
    levelScore=0;
    levelTime=0;
    timeSinceEaten=0;
    if (level>2)
    {
      gameStatus=2;
    }
  }
}

public void lose()
{
  if (lives<0)
  {
    gameStatus=3;
  }
}


//ghosts by name maybe should think of a better way to set this up
float blinkyX, blinkyY, pinkyX, pinkyY, inkyX, inkyY, clydeX, clydeY,ghostSizeX,ghostSizeY,ghostSpeed;
//PImage blinky, pinky, inky, clyde, blinkyBlue, pinkyBlue, inkyBlue, clydeBlue, blinkyEye, pinkyEye, inkyEye, clydeEye;
int blinkyDirection, pinkyDirection, inkyDirection, clydeDirection;
boolean blinkyGo,pinkyGo,inkyGo,clydeGo;

public void ghostSetup()
{
  blinkyX = width*0.475f;
  blinkyY = 28.5f*y;
  pinkyX = width*0.475f;
  pinkyY = 28.5f*y;
  inkyX = width*0.475f;
  inkyY = 28.5f*y;
  clydeX = width*0.475f;
  clydeY = 28.5f*y;
  ghostSizeX = 5.5f*x;
  ghostSizeY = 4*y;
  blinkyDirection=2;
  pinkyDirection=4;
  inkyDirection=2;
  clydeDirection=4;
  blinkyGo=false;
  pinkyGo=false;
  inkyGo=false;
  clydeGo=false;
  ghostSpeed=0.3f*x;
}

public void drawGhost (float a, float b, float sx, float sy, int c)
{
  ellipseMode(CORNER);
  fill(c);
  ellipse(a,b,sx,sy);
  ellipseMode(CENTER);
}

public void ghostActions()
{
  blinkyMovement();
  inkyMovement();
  pinkyMovement();
  clydeMovement();
  blinkyX=teleport(blinkyX,blinkyY);
  inkyX=teleport(inkyX,inkyY);
  pinkyX=teleport(pinkyX,pinkyY);
  clydeX=teleport(clydeX,clydeY);
  ghostEat();
}

public void ghostEat()
{
  if ((blinkyX>(pacManX-(pacManSizeX*0.2f))&&(blinkyX<(pacManX+(pacManSizeX*0.8f)))&&(blinkyY>(pacManY-(pacManSizeY*0.2f)))&&blinkyY<(pacManY+(pacManSizeY*0.8f))))
  {
    loseLife();
  }
  if ((inkyX>(pacManX-(pacManSizeX*0.2f))&&(inkyX<(pacManX+(pacManSizeX*0.8f)))&&(inkyY>(pacManY-(pacManSizeY*0.5f)))&&inkyY<(pacManY+(pacManSizeY*0.8f))))
  {
    loseLife();
  }
  if ((pinkyX>(pacManX-(pacManSizeX*0.2f))&&(pinkyX<(pacManX+(pacManSizeX*0.8f)))&&(pinkyY>(pacManY-(pacManSizeY*0.5f)))&&pinkyY<(pacManY+(pacManSizeY*0.8f))))
  {
    loseLife();
  }
  if ((clydeX>(pacManX-(pacManSizeX*0.2f))&&(clydeX<(pacManX+(pacManSizeX*0.8f)))&&(clydeY>(pacManY-(pacManSizeY*0.5f)))&&clydeY<(pacManY+(pacManSizeY*0.8f))))
  {
    loseLife();
  }
}

public void loseLife()
{
  lives--;
  pacManSetup();
  ghostSetup();
  timeSinceEaten=0;
}
  
public void inkyMovement()
{
  if (inkyGo)
  {
    if(inkyDirection==1)
    {
      inkyY-=ghostSpeed;
    }
    else if(inkyDirection==2)
    {
      inkyX+=ghostSpeed;
    }
    else if(inkyDirection==3)
    {
      inkyY+=ghostSpeed;
    }
    else if(inkyDirection==4)
    {
      inkyX-=ghostSpeed;
    }
    
    for (int i=0;i<66;i++)
    {
      if ((inkyX>corners[i][0]-(ghostSpeed-1))&&(inkyX<corners[i][0]+(ghostSpeed-1))&&(inkyY>corners[i][1]-(ghostSpeed-1))&&(inkyY<corners[i][1]+(ghostSpeed-1)))
      {
        if (inkyDirection==1)
        {
          if (corners[i][2]==0)
          {
            if ((corners[i][3]==1)&&(corners[i][5]==0)) {inkyDirection=2;}
            else if ((corners[i][3]==0)&&(corners[i][5]==1)) {inkyDirection=4;}
            else
            {
              if (pacManX<inkyX) {inkyDirection=4;}
              else {inkyDirection=2;}
            }
          }
        }
        else if (inkyDirection==2)
        {
          if (corners[i][3]==0)
          {
            if ((corners[i][2]==1)&&(corners[i][4]==0)) {inkyDirection=1;}
            else if ((corners[i][2]==0)&&(corners[i][4]==1)) {inkyDirection=3;}
            else
            {
              if (pacManY<inkyY) {inkyDirection=1;}
              else {inkyDirection=3;}
            }
          }
        }
        else if (inkyDirection==3)
        {
          if (corners[i][4]==0)
          {
            if ((corners[i][3]==1)&&(corners[i][5]==0)) {inkyDirection=2;}
            else if ((corners[i][3]==0)&&(corners[i][5]==1)) {inkyDirection=4;}
            else
            {
              if (pacManX<inkyX) {inkyDirection=4;}
              else {inkyDirection=2;}
            }
          }
        }
        else
        {
          if (corners[i][5]==0)
          {
            if ((corners[i][2]==1)&&(corners[i][4]==0)) {inkyDirection=1;}
            else if ((corners[i][2]==0)&&(corners[i][4]==1)) {inkyDirection=3;}
            else
            {
              if(pacManY<inkyY) {inkyDirection=1;}
              else {inkyDirection=3;}
            }
          }
        }
      }
    }
    image(inky,inkyX,inkyY,ghostSizeX,ghostSizeY);
  }
}

public void blueInkyMovement()
{
  if (inkyGo)
  {
    if(inkyDirection==1)
    {
      inkyY-=ghostSpeed;
    }
    else if(inkyDirection==2)
    {
      inkyX+=ghostSpeed;
    }
    else if(inkyDirection==3)
    {
      inkyY+=ghostSpeed;
    }
    else if(inkyDirection==4)
    {
      inkyX-=ghostSpeed;
    }
    
    for (int i=0;i<66;i++)
    {
      if ((inkyX>corners[i][0]-(ghostSpeed-1))&&(inkyX<corners[i][0]+(ghostSpeed-1))&&(inkyY>corners[i][1]-(ghostSpeed-1))&&(inkyY<corners[i][1]+(ghostSpeed-1)))
      {
        if (inkyDirection==1)
        {
          if (corners[i][2]==0)
          {
            if ((corners[i][3]==1)&&(corners[i][5]==0)) {inkyDirection=2;}
            else if ((corners[i][3]==0)&&(corners[i][5]==1)) {inkyDirection=4;}
            else
            {
              if (pacManX>inkyX) {inkyDirection=4;}
              else {inkyDirection=2;}
            }
          }
        }
        else if (inkyDirection==2)
        {
          if (corners[i][3]==0)
          {
            if ((corners[i][2]==1)&&(corners[i][4]==0)) {inkyDirection=1;}
            else if ((corners[i][2]==0)&&(corners[i][4]==1)) {inkyDirection=3;}
            else
            {
              if (pacManY>inkyY) {inkyDirection=1;}
              else {inkyDirection=3;}
            }
          }
        }
        else if (inkyDirection==3)
        {
          if (corners[i][4]==0)
          {
            if ((corners[i][3]==1)&&(corners[i][5]==0)) {inkyDirection=2;}
            else if ((corners[i][3]==0)&&(corners[i][5]==1)) {inkyDirection=4;}
            else
            {
              if (pacManX>inkyX) {inkyDirection=4;}
              else {inkyDirection=2;}
            }
          }
        }
        else
        {
          if (corners[i][5]==0)
          {
            if ((corners[i][2]==1)&&(corners[i][4]==0)) {inkyDirection=1;}
            else if ((corners[i][2]==0)&&(corners[i][4]==1)) {inkyDirection=3;}
            else
            {
              if(pacManY>inkyY) {inkyDirection=1;}
              else {inkyDirection=3;}
            }
          }
        }
      }
    }
    image(ghostBlue,inkyX,inkyY,ghostSizeX,ghostSizeY);
  }
}
//The Movement
float direction, speed;

public void mouseClicked()
{
  if (gameStatus==1)
  {
    if ((mouseX<(46*x)+(7*x))&&(mouseX>(46*x))&&(mouseY<(83.5f*y)+(6*y))&&(mouseY>(83.5f*y)))
    {
      for (int i=0; i<66; i++)
      {
        if ((pacManX>corners[i][0]-x)&&(pacManX<corners[i][0]+(2*x))&&(pacManY>corners[i][1]-y)&&(pacManY<corners[i][1]+(2*y)))
        {
          if (corners[i][2]==1)
          {
            direction=1;
          }
        }
        else
        {
          if (direction==3)
          {
            direction=1;
          }
        }
      } 
    }
    else if ((mouseX<(52*x)+(7*x))&&(mouseX>(52*x))&&(mouseY<(87.5f*y)+(6*y))&&(mouseY>(87.5f*y)))
    {
      for (int i=0;i<66;i++)
      {
        if((pacManX>corners[i][0]-x)&&(pacManX<corners[i][0]+(2*x))&&(pacManY>corners[i][1]-y)&&(pacManY<corners[i][1]+(2*y)))
        {
          if (corners[i][3]==1)
          {
            direction=2;
          }
        }
        else
        {
          if (direction==4)
          {
            direction=2;
          }
        }
      }
    }
    else if ((mouseX<(46*x)+(7*x))&&(mouseX>(46*x))&&(mouseY<(92*y)+(6*y))&&(mouseY>(92*y)))
    {
      for (int i=0;i<66;i++)
      {
        if((pacManX>corners[i][0]-x)&&(pacManX<corners[i][0]+(2*x))&&(pacManY>corners[i][1]-y)&&(pacManY<corners[i][1]+(2*y)))
        {
          if (corners[i][4]==1)
          {
            direction=3;
          }
        }
        else
        {
          if (direction==1)
          {
            direction=3;
          }
        }
      }
    }
    else if ((mouseX<(40*x)+(7*x))&&(mouseX>(40*x))&&(mouseY<(87.5f*y)+(6*y))&&(mouseY>(87.5f*y)))
    {
      for (int i=0;i<66;i++)
      {
        if((pacManX>corners[i][0]-x)&&(pacManX<corners[i][0]+(2*x))&&(pacManY>corners[i][1]-y)&&(pacManY<corners[i][1]+(2*y)))
        {
          if (corners[i][5]==1)
          {
            direction=4;
          }
        }
        else
        {
          if (direction==2)
          {
            direction=4;
          }
        }
      }
    }
  }
  if ((mouseX>(3*x))&&(mouseX<(29*x))&&(mouseY>(83*y))&&(mouseY<(98*y)))
  {
    exit();
  }
  else if ((mouseX>(70*x))&&(mouseX<(96*x))&&(mouseY>(83*y))&&(mouseY<(98*y)))
  {
    if (gameStatus==0)
    {
      gameStatus=1;
    }
    else
    {
      setup();
    }
  }
}

public float teleport(float a, float b)
{
  float newXVal=a;
  if (a<0&&b>(34*x)&&b<(44*y))
  {
      newXVal=width-1;
  }
  else if (a>width&&b>(34*x)&&b<(44*y))
  {
      newXVal=1;
  }
  return newXVal;
}

public void movement()
{
  boolean blocked=false;
  if (direction==1)
  {
    for (int i=0; i<66; i++)
    {
      if ((pacManX>corners[i][0]-x)&&(pacManX<corners[i][0]+(2*x))&&(pacManY>corners[i][1]-y)&&(pacManY<corners[i][1]+(0.3f*y)))
      {       
        if (corners[i][2]==0)
        {
          blocked=true;
        }
      }
    }
    if (!blocked)
    {
      pacManY-=speed;
    }
  }
  else if (direction==2)
  {
    for (int i=0; i<66; i++)
    {
      if ((pacManX>corners[i][0])&&(pacManX<corners[i][0]+(2*x))&&(pacManY>corners[i][1]-y)&&(pacManY<corners[i][1]+(2*y)))
      {       
        if (corners[i][3]==0)
        {
          blocked=true;
        }
      }
    }
    if (!blocked)
    {
      pacManX+=speed;
    }
  }
  else if (direction==3)
  {
    for (int i=0; i<66; i++)
    {
      if ((pacManX>corners[i][0]-x)&&(pacManX<corners[i][0]+(2*x))&&(pacManY>corners[i][1])&&(pacManY<corners[i][1]+(2*y)))
      {       
        if (corners[i][4]==0)
        {
          blocked=true;
        }
      }
    }
    if (!blocked)
    {
      pacManY+=speed;
    }
  }
  else if (direction==4)
  {
    for (int i=0; i<66; i++)
    {
      if ((pacManX>corners[i][0]-(x))&&(pacManX<corners[i][0])&&(pacManY>corners[i][1]-y)&&(pacManY<corners[i][1]+(2*y)))
      {       
        if (corners[i][5]==0)
        {
          blocked=true;
        }
      }
    }
    if (!blocked)
    {
      pacManX-=speed;
    }
  }
}



public void keyPressed()
{
  if (key==CODED)
  {
    if (gameStatus==1)
    {
      if (keyCode==UP)
      {
        for (int i=0; i<66; i++)
        {
          if ((pacManX>corners[i][0]-x)&&(pacManX<corners[i][0]+(2*x))&&(pacManY>corners[i][1]-y)&&(pacManY<corners[i][1]+(2*y)))
          {
            if (corners[i][2]==1)
            {
              direction=1;
            }
          }
          else
          {
            if (direction==3)
            {
              direction=1;
            }
          }
        } 
      }
      else if (keyCode==RIGHT)
      {
        for (int i=0;i<66;i++)
        {
          if((pacManX>corners[i][0]-x)&&(pacManX<corners[i][0]+(2*x))&&(pacManY>corners[i][1]-y)&&(pacManY<corners[i][1]+(2*y)))
          {
            if (corners[i][3]==1)
            {
              direction=2;
            }
          }
          else
          {
            if (direction==4)
            {
              direction=2;
            }
          }
        }
      }
      else if (keyCode==DOWN)
      {
        for (int i=0;i<66;i++)
        {
          if((pacManX>corners[i][0]-x)&&(pacManX<corners[i][0]+(2*x))&&(pacManY>corners[i][1]-y)&&(pacManY<corners[i][1]+(2*y)))
          {
            if (corners[i][4]==1)
            {
              direction=3;
            }
          }
          else
          {
            if (direction==1)
            {
              direction=3;
            }
          }
        }
      }
      else if (keyCode==LEFT)
      {
        for (int i=0;i<66;i++)
        {
          if((pacManX>corners[i][0]-x)&&(pacManX<corners[i][0]+(2*x))&&(pacManY>corners[i][1]-y)&&(pacManY<corners[i][1]+(2*y)))
          {
            if (corners[i][5]==1)
            {
              direction=4;
            }
          }
          else
          {
            if (direction==2)
            {
              direction=4;
            }
          }
        }
      }
    }
    if (keyCode==ESC)
    {
      exit();
    }
  }
  else if (key == ' ')
  {
    if (gameStatus==0)
    {
      gameStatus=1;
    }
    else
    {
      setup();
    }
  }
}

//The player/pacman
float pacManX, pacManY, pacManSizeX, pacManSizeY;

public void drawPacman(float a, float b, float sa, float sb)
{
  /*fill(255,255,0);
  ellipseMode(CORNER);
  ellipse(a,b,sa,sb);
  ellipseMode(CENTER);*/
  image(student,a,b,sa,sb);
}

public void pacManSetup()
{
  //pacman size should be about 6x 4y
  pacManSizeX=5.5f*x; //may use slightly smaller size for the actual image, but measure using this/a little bigger than this
  pacManSizeY=4*y;
  pacManX=width*0.475f;
  pacManY=59.35f*y;
  direction=2;
  speed=0.4f*x;
}

public void eat()
{
  for (int i=0; i<pelletNo; i++)
  {
    if(pellets[i][0]==1)
    {
      if (((pellets[i][1]>pacManX)&&(pellets[i][1]<(pacManX+pacManSizeX)))&&((pellets[i][2]>pacManY)&&(pellets[i][2]<(pacManY+pacManSizeY))))
      {
        pellets[i][0]=0;
        score+=25*level;
      }
    }
  }
  for (int i=0; i<powerPelletsNo; i++)
  {
    if(powerPellets[i][0]==1)
    {
      if (((powerPellets[i][1]>pacManX)&&(powerPellets[i][1]<(pacManX+pacManSizeX)))&&((powerPellets[i][2]>pacManY)&&(powerPellets[i][2]<(pacManY+pacManSizeY))))
      {
        powerPellets[i][0]=0;
        levelScore+=10*level;
        powerPelletEaten=true;
        timeSincePowerPellet=0;
        blinkyDirection=reverseDirection(blinkyDirection);
        inkyDirection=reverseDirection(inkyDirection);
        pinkyDirection=reverseDirection(pinkyDirection);
        clydeDirection=reverseDirection(clydeDirection);
      }
    }
  }
}

public int reverseDirection (int d)
{
  if (d==1)
  {
    return 3;
  }
  else if (d==2)
  {
    return 4;
  }
  else if (d==3)
  {
    return 1;
  }
  else
  {
    return 2;
  }
}

public void eatGhosts()
{
  if ((blinkyX>(pacManX-(pacManSizeX*0.2f))&&(blinkyX<(pacManX+(pacManSizeX*0.8f)))&&(blinkyY>(pacManY-(pacManSizeY*0.2f)))&&blinkyY<(pacManY+(pacManSizeY*0.8f))))
  {
    blinkyX = width*0.475f;
    blinkyY = 28.5f*y;
    score+=100*level;
    blinkyDirection=2;
  }
  if ((inkyX>(pacManX-(pacManSizeX*0.2f))&&(inkyX<(pacManX+(pacManSizeX*0.8f)))&&(inkyY>(pacManY-(pacManSizeY*0.5f)))&&inkyY<(pacManY+(pacManSizeY*0.8f))))
  {
    inkyX = width*0.475f;
    inkyY = 28.5f*y;
    score+=100*level;
    inkyDirection=2;
  }
  if ((pinkyX>(pacManX-(pacManSizeX*0.2f))&&(pinkyX<(pacManX+(pacManSizeX*0.8f)))&&(pinkyY>(pacManY-(pacManSizeY*0.5f)))&&pinkyY<(pacManY+(pacManSizeY*0.8f))))
  {
    pinkyX = width*0.475f;
    pinkyY = 28.5f*y;
    score+=100*level;
    pinkyDirection=2;
  }
  if ((clydeX>(pacManX-(pacManSizeX*0.2f))&&(clydeX<(pacManX+(pacManSizeX*0.8f)))&&(clydeY>(pacManY-(pacManSizeY*0.5f)))&&clydeY<(pacManY+(pacManSizeY*0.8f))))
  {
    clydeX = width*0.475f;
    clydeY = 28.5f*y;
    score+=100*level;
    clydeDirection=2;
  }
}
//Pellets for collection
float [][] pellets;
float pelletSizeX, pelletSizeY; 
int pelletNo;
PImage pellet;


public void pellet()
{
  for(int i=0; i<pelletNo;i++)
  {
    if (pellets[i][0]==1)
    {
      drawPellet(pellets[i][1],pellets[i][2]);
    }
  }
}


public void drawPellet(float a, float b)
{
  fill(255,0,0);
  //ellipse(a,b,pelletSizeX,pelletSizeY);
  image(pellet,a-(0.5f*x),b-(0.5f*y),pelletSizeX*1.5f,pelletSizeY*1.5f);
}


public void pelletsSetup()
{
  pelletSizeX=x;
  pelletSizeY=y;
  pelletNo=242;
  pellets=new float[pelletNo][arrayDepth];
  for (int i=0; i<pelletNo;i++)
  {
    pellets[i][0]=1;
  }
  
  //Row 1 of 29
  for( int i=0; i<12; i++)
  {
    pellets[i][1]=(i*(3.6f*x)+(5.5f*x));
    pellets[i][2]=4*y;
  }
  for( int i=12; i<24; i++)
  {
    pellets[i][1]=(i*(3.6f*x)+(12.6f*x));
    pellets[i][2]=4*y;
  }
  
  //row 2 of 29
  pellets[24][1]=(0*(3.6f*x)+(5.5f*x));
  pellets[24][2]=(1*(2.6f*y))+(4*y);
  pellets[25][1]=(5*(3.6f*x)+(5.5f*x));
  pellets[25][2]=(1*(2.6f*y))+(4*y);
  pellets[26][1]=(11*(3.6f*x)+(5.5f*x));
  pellets[26][2]=(1*(2.6f*y))+(4*y);
  pellets[27][1]=(14*(3.6f*x)+(5.5f*x));
  pellets[27][2]=(1*(2.6f*y))+(4*y);
  pellets[28][1]=(20*(3.6f*x)+(5.5f*x));
  pellets[28][2]=(1*(2.6f*y))+(4*y);
  pellets[29][1]=(25*(3.6f*x)+(5.5f*x));
  pellets[29][2]=(1*(2.6f*y))+(4*y);
  
  //row 3 of 29
  pellets[30][1]=(5*(3.6f*x)+(5.5f*x));
  pellets[30][2]=(2*(2.6f*y))+(4*y);
  pellets[31][1]=(11*(3.6f*x)+(5.5f*x));
  pellets[31][2]=(2*(2.6f*y))+(4*y);
  pellets[32][1]=(14*(3.6f*x)+(5.5f*x));
  pellets[32][2]=(2*(2.6f*y))+(4*y);
  pellets[33][1]=(20*(3.6f*x)+(5.5f*x));
  pellets[33][2]=(2*(2.6f*y))+(4*y);
  
  //row 4 of 29
  pellets[34][1]=(0*(3.6f*x)+(5.5f*x));
  pellets[34][2]=(3*(2.6f*y))+(4*y);
  pellets[35][1]=(5*(3.6f*x)+(5.5f*x));
  pellets[35][2]=(3*(2.6f*y))+(4*y);
  pellets[36][1]=(11*(3.6f*x)+(5.5f*x));
  pellets[36][2]=(3*(2.6f*y))+(4*y);
  pellets[37][1]=(14*(3.6f*x)+(5.5f*x));
  pellets[37][2]=(3*(2.6f*y))+(4*y);
  pellets[38][1]=(20*(3.6f*x)+(5.5f*x));
  pellets[38][2]=(3*(2.6f*y))+(4*y);
  pellets[39][1]=(25*(3.6f*x)+(5.5f*x));
  pellets[39][2]=(3*(2.6f*y))+(4*y);
  
  //row 5 of 29
  for( int i=40; i<66; i++)
  {
    pellets[i][1]=((i-40)*(3.6f*x)+(5.5f*x));
    pellets[i][2]=(4*(2.6f*y))+(4*y);
  }
  
  //row 6 of 29
  pellets[66][1]=(0*(3.6f*x)+(5.5f*x));
  pellets[66][2]=(5*(2.6f*y))+(4*y);
  pellets[67][1]=(5*(3.6f*x)+(5.5f*x));
  pellets[67][2]=(5*(2.6f*y))+(4*y);
  pellets[68][1]=(8*(3.6f*x)+(5.5f*x));
  pellets[68][2]=(5*(2.6f*y))+(4*y);
  pellets[69][1]=(17*(3.6f*x)+(5.5f*x));
  pellets[69][2]=(5*(2.6f*y))+(4*y);
  pellets[70][1]=(20*(3.6f*x)+(5.5f*x));
  pellets[70][2]=(5*(2.6f*y))+(4*y);
  pellets[71][1]=(25*(3.6f*x)+(5.5f*x));
  pellets[71][2]=(5*(2.6f*y))+(4*y);
  
  //row 7 of 29
  pellets[72][1]=(0*(3.6f*x)+(5.5f*x));
  pellets[72][2]=(6*(2.6f*y))+(4*y);  
  pellets[73][1]=(5*(3.6f*x)+(5.5f*x));
  pellets[73][2]=(6*(2.6f*y))+(4*y);
  pellets[74][1]=(8*(3.6f*x)+(5.5f*x));
  pellets[74][2]=(6*(2.6f*y))+(4*y);
  pellets[75][1]=(17*(3.6f*x)+(5.5f*x));
  pellets[75][2]=(6*(2.6f*y))+(4*y);
  pellets[76][1]=(20*(3.6f*x)+(5.5f*x));
  pellets[76][2]=(6*(2.6f*y))+(4*y);
  pellets[77][1]=(25*(3.6f*x)+(5.5f*x));
  pellets[77][2]=(6*(2.6f*y))+(4*y);
  
  //row 8 of 29
  for (int i=78;i<84;i++)
  {
    pellets[i][1]=((i-78)*(3.6f*x)+(5.5f*x));
    pellets[i][2]=(7*(2.6f*y))+(4*y);
  }
  for (int i=84;i<88;i++)
  {
    pellets[i][1]=((i-76)*(3.6f*x)+(5.5f*x));
    pellets[i][2]=(7*(2.6f*y))+(4*y);
  }
  for (int i=88;i<92;i++)
  {
    pellets[i][1]=((i-74)*(3.6f*x)+(5.5f*x));
    pellets[i][2]=(7*(2.6f*y))+(4*y);
  }
  for (int i=92;i<98;i++)
  {
    pellets[i][1]=((i-72)*(3.6f*x)+(5.5f*x));
    pellets[i][2]=(7*(2.6f*y))+(4*y);
  }
  
  //rows 9-19 of 29
  for (int i=98;i<109;i++)
  {
    pellets[i][1]=(5*(3.6f*x)+(5.5f*x));
    pellets[i][2]=((i-98)*(2.6f*y)+(4*y)+(20.8f*y));
  }
  for (int i=109;i<120;i++)
  {
    pellets[i][1]=(20*(3.6f*x)+(5.5f*x));
    pellets[i][2]=((i-109)*(2.6f*y)+(4*y)+(20.8f*y));
  }
  
  //row 20 of 29
  for (int i=120;i<132;i++)
  {
    pellets[i][1]=((i-120)*(3.6f*x)+(5.5f*x));
    pellets[i][2]=(19*(2.6f*y))+(4*y);
  }
  for (int i=132;i<144;i++)
  {
    pellets[i][1]=((i-118)*(3.6f*x)+(5.5f*x));
    pellets[i][2]=(19*(2.6f*y))+(4*y);
  }
  
  //row 21 of 29
  pellets[144][1]=(0*(3.6f*x)+(5.5f*x));
  pellets[144][2]=(20*(2.6f*y))+(4*y);
  pellets[145][1]=(5*(3.6f*x)+(5.5f*x));
  pellets[145][2]=(20*(2.6f*y))+(4*y);
  pellets[146][1]=(11*(3.6f*x)+(5.5f*x));
  pellets[146][2]=(20*(2.6f*y))+(4*y);
  pellets[147][1]=(14*(3.6f*x)+(5.5f*x));
  pellets[147][2]=(20*(2.6f*y))+(4*y);
  pellets[148][1]=(20*(3.6f*x)+(5.5f*x));
  pellets[148][2]=(20*(2.6f*y))+(4*y);
  pellets[149][1]=(25*(3.6f*x)+(5.5f*x));
  pellets[149][2]=(20*(2.6f*y))+(4*y);
  
  //row 22 of 29
  pellets[150][1]=(5*(3.6f*x)+(5.5f*x));
  pellets[150][2]=(21*(2.6f*y))+(4*y);
  pellets[151][1]=(11*(3.6f*x)+(5.5f*x));
  pellets[151][2]=(21*(2.6f*y))+(4*y);
  pellets[152][1]=(14*(3.6f*x)+(5.5f*x));
  pellets[152][2]=(21*(2.6f*y))+(4*y);
  pellets[153][1]=(20*(3.6f*x)+(5.5f*x));
  pellets[153][2]=(21*(2.6f*y))+(4*y);
  
  //row 23 of 29
  for (int i=154;i<157;i++)
  {
    pellets[i][1]=((i-154)*(3.6f*x)+(5.5f*x));
    pellets[i][2]=(22*(2.6f*y))+(4*y);
  }
  for (int i=157;i<173;i++)
  {
    pellets[i][1]=((i-152)*(3.6f*x)+(5.5f*x));
    pellets[i][2]=(22*(2.6f*y))+(4*y);
  }
  for (int i=173;i<176;i++)
  {
    pellets[i][1]=((i-150)*(3.6f*x)+(5.5f*x));
    pellets[i][2]=(22*(2.6f*y))+(4*y);
  }
  
  //row 24 of 29
  pellets[176][1]=(2*(3.6f*x)+(5.5f*x));
  pellets[176][2]=(23*(2.6f*y))+(4*y);
  pellets[177][1]=(5*(3.6f*x)+(5.5f*x));
  pellets[177][2]=(23*(2.6f*y))+(4*y);
  pellets[178][1]=(8*(3.6f*x)+(5.5f*x));
  pellets[178][2]=(23*(2.6f*y))+(4*y);
  pellets[179][1]=(17*(3.6f*x)+(5.5f*x));
  pellets[179][2]=(23*(2.6f*y))+(4*y);
  pellets[180][1]=(20*(3.6f*x)+(5.5f*x));
  pellets[180][2]=(23*(2.6f*y))+(4*y);
  pellets[181][1]=(23*(3.6f*x)+(5.5f*x));
  pellets[181][2]=(23*(2.6f*y))+(4*y);
  
  //row 25 of 29
  pellets[182][1]=(2*(3.6f*x)+(5.5f*x));
  pellets[182][2]=(24*(2.6f*y))+(4*y);
  pellets[183][1]=(5*(3.6f*x)+(5.5f*x));
  pellets[183][2]=(24*(2.6f*y))+(4*y);
  pellets[184][1]=(8*(3.6f*x)+(5.5f*x));
  pellets[184][2]=(24*(2.6f*y))+(4*y);
  pellets[185][1]=(17*(3.6f*x)+(5.5f*x));
  pellets[185][2]=(24*(2.6f*y))+(4*y);
  pellets[186][1]=(20*(3.6f*x)+(5.5f*x));
  pellets[186][2]=(24*(2.6f*y))+(4*y);
  pellets[187][1]=(23*(3.6f*x)+(5.5f*x));
  pellets[187][2]=(24*(2.6f*y))+(4*y);
  
  //row 26 of 29
  for (int i=188;i<194;i++)
  {
    pellets[i][1]=((i-188)*(3.6f*x)+(5.5f*x));
    pellets[i][2]=(25*(2.6f*y))+(4*y);
  }
  for (int i=194;i<198;i++)
  {
    pellets[i][1]=((i-186)*(3.6f*x)+(5.5f*x));
    pellets[i][2]=(25*(2.6f*y))+(4*y);
  }
  for (int i=198;i<202;i++)
  {
    pellets[i][1]=((i-184)*(3.6f*x)+(5.5f*x));
    pellets[i][2]=(25*(2.6f*y))+(4*y);
  }
  for (int i=202;i<208;i++)
  {
    pellets[i][1]=((i-182)*(3.6f*x)+(5.5f*x));
    pellets[i][2]=(25*(2.6f*y))+(4*y);
  }
  
  //row 27 of 29
  pellets[208][1]=(0*(3.6f*x)+(5.5f*x));
  pellets[208][2]=(26*(2.6f*y))+(4*y);
  pellets[209][1]=(11*(3.6f*x)+(5.5f*x));
  pellets[209][2]=(26*(2.6f*y))+(4*y);
  pellets[210][1]=(14*(3.6f*x)+(5.5f*x));
  pellets[210][2]=(26*(2.6f*y))+(4*y);
  pellets[211][1]=(25*(3.6f*x)+(5.5f*x));
  pellets[211][2]=(26*(2.6f*y))+(4*y);
  
  //row 28 of 29
  pellets[212][1]=(0*(3.6f*x)+(5.5f*x));
  pellets[212][2]=(27*(2.6f*y))+(4*y);
  pellets[213][1]=(11*(3.6f*x)+(5.5f*x));
  pellets[213][2]=(27*(2.6f*y))+(4*y);
  pellets[214][1]=(14*(3.6f*x)+(5.5f*x));
  pellets[214][2]=(27*(2.6f*y))+(4*y);
  pellets[215][1]=(25*(3.6f*x)+(5.5f*x));
  pellets[215][2]=(27*(2.6f*y))+(4*y);
  
  //row 29 of 29
  for (int i=216;i<242;i++)
  {
    pellets[i][1]=((i-216)*(3.6f*x)+(5.5f*x));
    pellets[i][2]=(28*(2.6f*y))+(4*y);
  }
}
public void pinkyMovement()
{
  if (pinkyGo)
  {
    if(pinkyDirection==1)
    {
      pinkyY-=ghostSpeed;
    }
    else if(pinkyDirection==2)
    {
      pinkyX+=ghostSpeed;
    }
    else if(pinkyDirection==3)
    {
      pinkyY+=ghostSpeed;
    }
    else if(pinkyDirection==4)
    {
      pinkyX-=ghostSpeed;
    }
    
    for (int i=0;i<66;i++)
    {
      if ((pinkyX>corners[i][0]-(ghostSpeed-1))&&(pinkyX<corners[i][0]+(ghostSpeed-1))&&(pinkyY>corners[i][1]-(ghostSpeed-1))&&(pinkyY<corners[i][1]+(ghostSpeed-1)))
      {
        if (pinkyDirection==1)
        {
          if (corners[i][2]==0)
          {
            if ((corners[i][3]==1)&&(corners[i][5]==0)) {pinkyDirection=2;}
            else if ((corners[i][3]==0)&&(corners[i][5]==1)) {pinkyDirection=4;}
            else
            {
              if ((pacManX+(20*x))<pinkyX) {pinkyDirection=4;}
              else {pinkyDirection=2;}
            }
          }
          else
          {
            if((corners[i][3]==1)&&(corners[i][5]==0))
            {
              if ((pacManY-(20*y))>pinkyY) {pinkyDirection=2;}
            }
            else if ((corners[i][3]==0)&&(corners[i][5]==1))
            {
              if ((pacManY-(20*y))>pinkyY) {pinkyDirection=4;}
            }
            else
            {
              if ((pacManY-(20*y))>pinkyY)
              {
                if ((pacManX+(20*x))<pinkyX) {pinkyDirection=4;}
                else {pinkyDirection=2;}
              }
            }
          }
        }
        else if (pinkyDirection==2)
        {
          if (corners[i][3]==0)
          {
            if ((corners[i][2]==1)&&(corners[i][4]==0)) {pinkyDirection=1;}
            else if ((corners[i][2]==0)&&(corners[i][4]==1)) {pinkyDirection=3;}
            else
            {
              if ((pacManY-(20*y))<pinkyY) {pinkyDirection=1;}
              else {pinkyDirection=3;}
            }
          }
          else
          {
            if ((corners[i][2]==1)&&(corners[i][4]==0))
            {
              if ((pacManX+(20*x))<pinkyX) {pinkyDirection=1;}
            }
            else if ((corners[i][2]==0)&&(corners[i][4]==1))
            {
              if ((pacManX+(20*x))<pinkyX) {pinkyDirection=3;}
            }
            else
            {
              if ((pacManX+(20*x))<pinkyX)
              {
                if ((pacManY-(20*y))<pinkyY) {pinkyDirection=1;}
                else {pinkyDirection=3;}
              }
            }
          }
        }
        else if (pinkyDirection==3)
        {
          if (corners[i][4]==0)
          {
            if ((corners[i][3]==1)&&(corners[i][5]==0)) {pinkyDirection=2;}
            else if ((corners[i][3]==0)&&(corners[i][5]==1)) {pinkyDirection=4;}
            else
            {
              if ((pacManX+(20*x))<pinkyX) {pinkyDirection=4;}
              else {pinkyDirection=2;}
            }
          }
          else
          {
            if ((corners[i][3]==1)&&(corners[i][5]==0))
            {
              if ((pacManY-(20*y))<pinkyY) {pinkyDirection=2;}
            }
            else if ((corners[i][3]==0)&&(corners[i][5]==1))
            {
              if ((pacManY-(20*y))<pinkyY) {pinkyDirection=4;}
            }
            else
            {
              if ((pacManY-(20*y))<pinkyY)
              {
                if ((pacManX+(20*x))<pinkyX) {pinkyDirection=4;}
                else {pinkyDirection=2;}
              }
            }
          }
        }
        else
        {
          if (corners[i][5]==0)
          {
            if ((corners[i][2]==1)&&(corners[i][4]==0)) {pinkyDirection=1;}
            else if ((corners[i][2]==0)&&(corners[i][4]==1)) {pinkyDirection=3;}
            else
            {
              if((pacManY-(20*y))<pinkyY) {pinkyDirection=1;}
              else {pinkyDirection=3;}
            }
          }
          else
          {
            if ((corners[i][2]==1)&&(corners[i][4]==0))
            {
              if ((pacManX+(20*x))>pinkyX) {pinkyDirection=1;}
            }
            else if ((corners[i][2]==0)&&(corners[i][4]==1))
            {
              if ((pacManX+(20*x))>pinkyX) {pinkyDirection=3;}
            }
            else 
            {
              if ((pacManX+(20*x))>pinkyX) 
              {
                if ((pacManY-(20*y))<pinkyY) {pinkyDirection=1;}
                else {pinkyDirection=3;}
              }
            }
          }
        }
      }
    }
    image(pinky,pinkyX,pinkyY,ghostSizeX,ghostSizeY);
  }
}

public void bluePinkyMovement()
{
  if (pinkyGo)
  {
    if(pinkyDirection==1)
    {
      pinkyY-=ghostSpeed;
    }
    else if(pinkyDirection==2)
    {
      pinkyX+=ghostSpeed;
    }
    else if(pinkyDirection==3)
    {
      pinkyY+=ghostSpeed;
    }
    else if(pinkyDirection==4)
    {
      pinkyX-=ghostSpeed;
    }
    
    for (int i=0;i<66;i++)
    {
      if ((pinkyX>corners[i][0]-(ghostSpeed-1))&&(pinkyX<corners[i][0]+(ghostSpeed-1))&&(pinkyY>corners[i][1]-(ghostSpeed-1))&&(pinkyY<corners[i][1]+(ghostSpeed-1)))
      {
        if (pinkyDirection==1)
        {
          if (corners[i][2]==0)
          {
            if ((corners[i][3]==1)&&(corners[i][5]==0)) {pinkyDirection=2;}
            else if ((corners[i][3]==0)&&(corners[i][5]==1)) {pinkyDirection=4;}
            else
            {
              if ((pacManX+(20*x))>pinkyX) {pinkyDirection=4;}
              else {pinkyDirection=2;}
            }
          }
          else
          {
            if((corners[i][3]==1)&&(corners[i][5]==0))
            {
              if ((pacManY-(20*y))>pinkyY) {pinkyDirection=2;}
            }
            else if ((corners[i][3]==0)&&(corners[i][5]==1))
            {
              if ((pacManY-(20*y))>pinkyY) {pinkyDirection=4;}
            }
            else
            {
              if ((pacManY-(20*y))>pinkyY)
              {
                if (((pacManX+(20*x))+(20*x))>pinkyX) {pinkyDirection=4;}
                else {pinkyDirection=2;}
              }
            }
          }
        }
        else if (pinkyDirection==2)
        {
          if (corners[i][3]==0)
          {
            if ((corners[i][2]==1)&&(corners[i][4]==0)) {pinkyDirection=1;}
            else if ((corners[i][2]==0)&&(corners[i][4]==1)) {pinkyDirection=3;}
            else
            {
              if ((pacManY-(20*y))>pinkyY) {pinkyDirection=1;}
              else {pinkyDirection=3;}
            }
          }
          else
          {
            if ((corners[i][2]==1)&&(corners[i][4]==0))
            {
              if ((pacManX+(20*x))>pinkyX) {pinkyDirection=1;}
            }
            else if ((corners[i][2]==0)&&(corners[i][4]==1))
            {
              if ((pacManX+(20*x))>pinkyX) {pinkyDirection=3;}
            }
            else
            {
              if ((pacManX+(20*x))>pinkyX)
              {
                if ((pacManY-(20*y))>pinkyY) {pinkyDirection=1;}
                else {pinkyDirection=3;}
              }
            }
          }
        }
        else if (pinkyDirection==3)
        {
          if (corners[i][4]==0)
          {
            if ((corners[i][3]==1)&&(corners[i][5]==0)) {pinkyDirection=2;}
            else if ((corners[i][3]==0)&&(corners[i][5]==1)) {pinkyDirection=4;}
            else
            {
              if ((pacManX+(20*x))>pinkyX) {pinkyDirection=4;}
              else {pinkyDirection=2;}
            }
          }
          else
          {
            if ((corners[i][3]==1)&&(corners[i][5]==0))
            {
              if ((pacManY-(20*y))>pinkyY) {pinkyDirection=2;}
            }
            else if ((corners[i][3]==0)&&(corners[i][5]==1))
            {
              if ((pacManY-(20*y))>pinkyY) {pinkyDirection=4;}
            }
            else
            {
              if ((pacManY-(20*y))>pinkyY)
              {
                if ((pacManX+(20*x))>pinkyX) {pinkyDirection=4;}
                else {pinkyDirection=2;}
              }
            }
          }
        }
        else
        {
          if (corners[i][5]==0)
          {
            if ((corners[i][2]==1)&&(corners[i][4]==0)) {pinkyDirection=1;}
            else if ((corners[i][2]==0)&&(corners[i][4]==1)) {pinkyDirection=3;}
            else
            {
              if((pacManY-(20*y))>pinkyY) {pinkyDirection=1;}
              else {pinkyDirection=3;}
            }
          }
          else
          {
            if ((corners[i][2]==1)&&(corners[i][4]==0))
            {
              if ((pacManX+(20*x))>pinkyX) {pinkyDirection=1;}
            }
            else if ((corners[i][2]==0)&&(corners[i][4]==1))
            {
              if ((pacManX+(20*x))<pinkyX) {pinkyDirection=3;}
            }
            else 
            {
              if ((pacManX+(20*x))<pinkyX) 
              {
                if ((pacManY-(20*y))>pinkyY) {pinkyDirection=1;}
                else {pinkyDirection=3;}
              }
            }
          }
        }
      }
    }
    image(ghostBlue,pinkyX,pinkyY,ghostSizeX,ghostSizeY);
  }
}

//Power Pellets for collection
float[][] powerPellets;
int powerPelletsNo, timeSincePowerPellet; 
float powerPelletSizeX, powerPelletSizeY;
boolean powerPelletEaten;
PImage powerPellet1, powerPellet2, powerPellet;


public void drawPowerPellet(float a, float b)
{
  fill(255,0,0);
  //ellipse(a,b,powerPelletSizeX, powerPelletSizeY);
  image(powerPellet,a-(0.85f*powerPelletSizeX),b-(0.8f*powerPelletSizeY),powerPelletSizeX*1.8f,powerPelletSizeY*1.8f);
}



public void powerPellet()
{
  for (int i=0;i<powerPelletsNo;i++)
  {
    if (powerPellets[i][0]==1)
    {
      drawPowerPellet(powerPellets[i][1],powerPellets[i][2]);
    }
  }
}

public void eatPowerPellet()
{
  speed=0.5f*x;
  blueBlinkyMovement();
  bluePinkyMovement();
  blueInkyMovement();
  blueClydeMovement();
  timeSincePowerPellet++;
  if(timeSincePowerPellet>600)
  {
    powerPelletEaten=false;
    timeSincePowerPellet=0;
    speed=0.4f*x;
  }
}


public void powerPelletsSetup()
{
  powerPelletEaten=false;
  powerPelletSizeX=3*x;
  powerPelletSizeY=2.5f*y;
  powerPelletsNo=4;
  powerPellets=new float[powerPelletsNo][arrayDepth];
  for (int i=0;i<powerPelletsNo;i++)
  {
    powerPellets[i][0]=1;
  }
  powerPellets[0][1]=(5.5f*x);
  powerPellets[0][2]=(2*(2.6f*y))+(4*y);
  powerPellets[1][1]=(25*(3.6f*x)+(5.5f*x));
  powerPellets[1][2]=(2*(2.6f*y))+(4*y);
  powerPellets[2][1]=(5.5f*x);
  powerPellets[2][2]=(21*(2.6f*y))+(4*y);
  powerPellets[3][1]=(25*(3.6f*x)+(5.5f*x));
  powerPellets[3][2]=(21*(2.6f*y))+(4*y);
}
  static public void main(String[] passedArgs) {
    String[] appletArgs = new String[] { "Pacman" };
    if (passedArgs != null) {
      PApplet.main(concat(appletArgs, passedArgs));
    } else {
      PApplet.main(appletArgs);
    }
  }
}
